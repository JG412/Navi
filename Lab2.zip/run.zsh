#!/bin/zsh
g++ -std=c++20 -g -Wall *.cpp 
./a.out Maps/map1.txt 5 13